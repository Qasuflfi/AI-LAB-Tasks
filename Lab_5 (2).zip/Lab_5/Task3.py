# Lab 5: Branch Reordering Comparison
import math
# Minimax function
minimax_count = 0
def minimax(depth, index, maxTurn, scores, target):
    global minimax_count
    if depth == target:
        minimax_count += 1
        return scores[index]
    if maxTurn:
        return max (
            minimax(depth + 1, index * 2,
                    False, scores, target),
            minimax(depth + 1, index * 2 + 1,
                    False, scores, target)
        )
    else:
        return min(
            minimax(depth + 1, index * 2,
                    True, scores, target),
            minimax(depth + 1, index * 2 + 1,
                    True, scores, target)
        )
# Alpha-Beta function
alphabeta_count = 0
def alphabeta(depth, index, maxTurn, scores,
              target, alpha, beta):
    global alphabeta_count
    if depth == target:
        alphabeta_count += 1
        return scores[index]
    if maxTurn:
        value = float('-inf')
        for i in range(2):
            value = max(
                value,
                alphabeta(depth + 1, index * 2 + i,
                          False, scores, target, alpha, beta)
            )
            alpha = max(alpha, value)
            if alpha >= beta:
                break
        return value
    else:
        value = float('inf')
        for i in range(2):
            value = min(
                value,
                alphabeta(depth + 1, index * 2 + i,
                          True, scores, target, alpha, beta)
            )
            beta = min(beta, value)


            if alpha >= beta:
                break
        return value
# Original branch order
scores = [3, 5, 2, 9, 3, 5, 2, 9]
depth = int(math.log2(len(scores)))
m1 = minimax(0, 0, True, scores, depth)
a1 = alphabeta(0, 0, True, scores, depth,
               float('-inf'), float('inf'))
print("Original Order")
print("Minimax Value:", m1)
print("Minimax Leaves:", minimax_count)
print("Alpha-Beta Value:", a1)
print("Alpha-Beta Leaves:", alphabeta_count)
# Reset counters
minimax_count = 0
alphabeta_count = 0
# Reordered branch values
scores = [9, 2, 5, 3, 9, 2, 5, 3]
m2 = minimax(0, 0, True, scores, depth)
a2 = alphabeta(0, 0, True, scores, depth,
               float('-inf'), float('inf'))
print("\nReordered Order")
print("Minimax Value:", m2)
print("Minimax Leaves:", minimax_count)
print("Alpha-Beta Value:", a2)
print("Alpha-Beta Leaves:", alphabeta_count)