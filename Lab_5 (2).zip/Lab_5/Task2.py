import math
count = 0
def minimax(depth, index, maxTurn, scores, target):
    global count
    if depth == target:
        count += 1
        return scores[index]
    if maxTurn:
        return max(
            minimax(depth+1, index*2, False, scores, target),
            minimax(depth+1, index*2+1, False, scores, target)
        )
    else:
        return min(
            minimax(depth+1, index*2, True, scores, target),
            minimax(depth+1, index*2+1, True, scores, target)
        )
scores = [3, 5, 2, 9, 3, 5, 2, 9]
depth = int(math.log2(len(scores)))
result = minimax(0, 0, True, scores, depth)
print("Minimax Value:", result)
print("Evaluated Leaves:", count)