from lab6_search import Retriever

FAQ = [
    {
        "id": "faq:password",
        "question": "How do I reset my password?",
        "answer": "Use the recovery link on the login page.",
        "source": "it_help.txt"
    },
    {
        "id": "faq:submit",
        "question": "Where do I submit my assignment?",
        "answer": "Use the assignment upload page in the learning portal.",
        "source": "assessment.txt"
    },
    {
        "id": "faq:late",
        "question": "Can illness justify a late submission?",
        "answer": "Request an extension with medical evidence before the deadline.",
        "source": "handbook.txt"
    },
    {
        "id": "faq:library",
        "question": "What are the library opening hours?",
        "answer": "The library is open from 9 AM to 5 PM.",
        "source": "library.txt"
    },
    {
        "id": "faq:email",
        "question": "How can I contact the IT department?",
        "answer": "You can contact the IT department through the university help desk.",
        "source": "it_help.txt"
    }
]

def build_bot():
    records = [
        dict(r, text=r["question"] + " " + r["answer"])
        for r in FAQ
    ]
    return Retriever(records)

def reply(engine, query):
    if not query.strip():
        return "Please enter a question."

    for r in FAQ:
        if query.strip().casefold() == r["question"].casefold():
            return r["answer"] + " [source: " + r["source"] + "]"

    hits = engine.search(query)

    if not hits:
        return "No matching FAQ. Please contact the help desk."

    lines = ["Possible matches; choose or rephrase your question:"]

    for r, score in hits:
        lines.append(r["question"] + f" (similarity {score:.3f})")

    return "\n".join(lines)


if __name__ == "__main__":
    engine = build_bot()

    print("FAQ Assistant. Type exit to stop.")

    while True:
        query = input("You: ")

        if query.lower() == "exit":
            break

        print("Bot:", reply(engine, query))