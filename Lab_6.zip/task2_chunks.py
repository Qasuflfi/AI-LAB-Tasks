import re

# Three sample documents
docs = {
    "doc1": """
    University students must submit assignments through the online learning
    portal before the announced deadline. Every student should check the
    assignment instructions carefully before uploading a file. The portal
    accepts PDF and DOCX files for most written assignments. Students should
    make sure that their files are readable and correctly named. A submission
    receipt is generated after a successful upload. Students should save this
    receipt as proof of submission. Late submissions are normally not accepted
    without an approved extension. However, students who experience a serious
    medical emergency may request an extension by providing valid medical
    evidence before the deadline. The department reviews each request before
    making a decision. Students should contact their course instructor if
    they experience technical problems. Uploading a file does not guarantee
    that the submission is complete unless the confirmation message appears.
    Students are responsible for checking their submission status regularly.
    They should not wait until the final minutes to upload their work.
    """

    ,
    "doc2": """
    University students can access the library from Monday to Saturday.
    The normal opening hours are from 9 AM to 5 PM. Students must show
    their university identification cards when entering the library.
    Books can be borrowed using the library membership account. Students
    should return borrowed books before the due date to avoid late fees.
    The library provides computers, internet access, and quiet study areas.
    Students must maintain silence in reading rooms. Eating and drinking
    are not allowed near library computers. Students can renew a borrowed
    book online if another student has not reserved it. During examination
    weeks, the library may extend its opening hours after an official
    announcement. However, the library remains closed on public holidays
    unless special opening arrangements are announced. Students should
    check the university website for updated schedules. Lost books must
    be reported to the library staff immediately. Students are encouraged
    to use digital resources for research and academic learning.
    """

    ,
    "doc3": """
    Students can reset their university account password through the
    official login page. They should select the forgot password option
    and enter their registered university email address. A recovery link
    will be sent to that email address. Students should open the link and
    follow the instructions to create a new password. Passwords must be
    strong and should not be shared with other people. Students should
    avoid using their birthdays or simple personal information as passwords.
    If a student does not receive a recovery email, they should check the
    spam folder first. If the problem continues, they should contact the
    university IT help desk. The IT department may ask the student to
    verify their identity before restoring account access. Students should
    never share their recovery codes with anyone. In case of suspicious
    account activity, students should immediately report the issue to IT
    support. The university recommends changing passwords regularly.
    Keeping account details private helps protect academic records and
    personal information from unauthorized access.
    """
}


def word_spans(text):
    return [
        (m.start(), m.end())
        for m in re.finditer(r"\S+", text)
    ]


def windows(text, size=40, overlap=10, offset=0):

    if size <= 0 or not 0 <= overlap < size:
        raise ValueError(
            "Require size > 0 and 0 <= overlap < size"
        )

    spans = word_spans(text)
    result = []

    for i in range(0, len(spans), size - overlap):

        j = min(i + size, len(spans))

        result.append((
            offset + spans[i][0],
            offset + spans[j - 1][1]
        ))

        if j == len(spans):
            break

    return result


def sentence_chunks(text, size=40):

    if size <= 0:
        raise ValueError("size must be positive")

    cuts = [0] + [
        m.end()
        for m in re.finditer(r"[.!?]\s+", text)
    ] + [len(text)]

    out = []
    pending = None
    count = 0

    for a, b in zip(cuts, cuts[1:]):

        segment = text[a:b]
        n = len(segment.split())

        if not n:
            continue

        if n > size:

            if pending is not None:
                out.append(pending)

            out.extend(windows(segment, size, 0, a))
            pending, count = None, 0

        elif pending is not None and count + n <= size:

            pending, count = (pending[0], b), count + n

        else:

            if pending is not None:
                out.append(pending)

            pending, count = (a, b), n

    if pending is not None:
        out.append(pending)

    return out


def make_chunks(docs, strategy):

    result = []

    for doc_id, text in docs.items():

        if strategy == "sentence":
            spans = sentence_chunks(text)

        else:
            spans = windows(text, 40, int(strategy))

        for i, (a, b) in enumerate(spans):

            result.append({
                "id": f"{doc_id}:{i}",
                "doc": doc_id,
                "start": a,
                "end": b,
                "text": text[a:b]
            })

    return result
if __name__ == "__main__":

    # Basic tests
    assert windows("") == []
    assert windows("short text") == [(0, 10)]

    try:
        windows("a b", 2, 2)
    except ValueError:
        print("Invalid overlap test passed.")
    else:
        raise AssertionError("Invalid overlap was accepted")

    print("\nDocument word counts:")

    for doc_id, text in docs.items():
        print(doc_id, len(text.split()), "words")

    # Compare three chunking strategies
    for strategy in ["0", "10", "sentence"]:

        chunks = make_chunks(docs, strategy)

        print("\nStrategy:", strategy)
        print("Total chunks:", len(chunks))

        for c in chunks:

            assert c["text"] == docs[c["doc"]][
                c["start"]:c["end"]
            ]

            print("\nChunk ID:", c["id"])
            print("Words:", len(c["text"].split()))
            print("Offsets:", c["start"], c["end"])
            print("Text:", c["text"].strip())

    # Test sentence longer than budget
    long = " ".join(["word"] * 95) + "."

    assert all(
        len(long[a:b].split()) <= 40
        for a, b in sentence_chunks(long)
    )

    print("\nAll basic tests passed!")

# Check rule and exception preservation

rule_words = ["late submissions", "approved extension"]

for strategy in ["0", "10", "sentence"]:
    chunks = make_chunks(docs, strategy)

    doc1_chunks = [
        c["text"].lower() for c in chunks if c["doc"] == "doc1"
    ]

    rule_found = any(
        all(word in chunk for word in rule_words)
        for chunk in doc1_chunks
    )

    exception_found = any(
        re.search(
            r"serious\s+medical\s+emergency.*valid\s+medical\s+evidence",
            chunk,
            re.IGNORECASE
        )
        for chunk in doc1_chunks
    )

    print(f"\nStrategy: {strategy}")
    print("Rule preserved:", rule_found)
    print("Exception preserved:", exception_found)
