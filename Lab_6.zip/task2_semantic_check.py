from task2_chunks import docs, make_chunks
from lab6_search import Retriever, show_hits

# Generate chunks using 10-word overlap
chunks = make_chunks(docs, "10")

# Create records for retrieval
records = [
    {
        "id": c["id"],
        "text": c["text"],
        "doc": c["doc"],
        "start": c["start"],
        "end": c["end"]
    }
    for c in chunks
]

# Three paraphrased queries
queries = [
    "How can a student submit work after the deadline?",
    "When can students use the university library?",
    "What should I do if I cannot access my university account?"
]

# Compare TF-IDF and actual embeddings
for backend in ["tfidf", "embedding"]:

    print("\n" + "=" * 50)
    print("BACKEND:", backend.upper())
    print("=" * 50)

    engine = Retriever(records, backend=backend)

    for query in queries:

        print("\nQuery:", query)

        hits = engine.search(query, k=3)

        for record, score in hits:

            print("\nChunk ID:", record["id"])
            print("Document:", record["doc"])
            print("Score:", round(score, 3))
            print("Original evidence:")
            print(record["text"].strip())